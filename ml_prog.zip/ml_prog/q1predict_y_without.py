def barfn(val):
    temp=0
    for i in val:
        temp += i
    return temp/len(val)
def minusbarcal(val1,val2):
    return val1-val2
    #return temp
    
    
xi=[2,3,5,13,8,16,11,1,9]
yi=[15,28,42,64,50,90,58,8,54]
xminusxbar=[]
yminusybar=[]
xminusxbarmultiplyyminusybar=[]
xminusxbarsquare=[]
theta1=[]
xbar=barfn(xi)
ybar=barfn(yi)

for x in xi:
    #print(x)
    xminusxbar.append(round(minusbarcal(x,xbar),2))
for y in yi:
    yminusybar.append(round(minusbarcal(y,ybar),2))
i=0
while(i<len(xi)):
    xminusxbarmultiplyyminusybar.append(round((xminusxbar[i]*yminusybar[i]),2))
    i +=1;
for val in xminusxbar:
    xminusxbarsquare.append(round(val*val,2))
i=0
while(i<len(xi)):
    theta1.append(round((xminusxbar[i]*yminusybar[i])/xminusxbarsquare[i],2))
    i +=1
print("Xi = ",xminusxbar)
print("Yi = ",yminusybar)
print("xi-xbar",xminusxbarmultiplyyminusybar)
#print(sumxminusxbarmultiplyyminusybar)
print(sum(xminusxbarmultiplyyminusybar))
print(xminusxbarsquare)
print(sum(xminusxbarsquare))
print(theta1)
thetaone=round(sum(xminusxbarmultiplyyminusybar)/sum(xminusxbarsquare),2)
thetazero=round(ybar-thetaone*xbar,2)
print(thetaone)
print(thetazero)
x=int(input("Enter x"))
y=thetaone*x+thetazero
print("predicted y is ",y)
print(x)
#print(xbar)
#print(ybar)

