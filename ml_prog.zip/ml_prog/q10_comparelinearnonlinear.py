import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn import linear_model
from sklearn.metrics import r2_score
from sklearn.preprocessing import PolynomialFeatures
#data extraction
df=pd.read_csv('CO2_Emissions_Canada.csv')
df.info()
print(df.head(10))
print("press any key ")
print(df.describe())
print("press any key")
#descriptive statisctics
print(df.describe())
print("press any key")
df_x=df[['enginsize']]
df_y=df[['co2']]
plt.scatter(df_x,df_y)
plt.xlabel('Engine size')
plt.ylabel('Co2 Emissions')
plt.show()
#fitting before testing for model 02
poly_features=PolynomialFeatures(degree=2)
df_x_f=poly_features.fit_transform(df_x)
#train test split model 01------
x_train,x_test,y_train,y_test=train_test_split(df_x,df_y,test_size=0.33,random_state=40)
#train test split model 02------
x1_train,x1_test,y1_train,y1_test=train_test_split(df_x_f,df_y,test_size=0.33,random_state=40)
#model fitting model 01
regr=linear_model.LinearRegression()
regr.fit(x_train,y_train)
#Trainning model 02
nonlinear_regr=linear_model.LinearRegression()
nonlinear_regr.fit(x1_train,y1_train)
#testing model 01
test_y_hat=regr.predict(x_test)
mse=np.mean(np.absolute(test_y_hat-y_test)**2)
r2score=r2_score(test_y_hat,y_test)
print("Linear Regression")
print('mean square error is [0]:',format(mse))
print('r2 score is [0]',format(r2score))
test_y_hat2=nonlinear_regr.predict(x1_test)
mse2=np.mean(np.absolute(test_y_hat2-y1_test)**2)
r2score1=r2_score(test_y_hat2,y1_test)
print("Non Linear Regression")
print('mean square error is [0]:',format(mse2))
print('r2 score is [0]',format(r2score1))
#model validation testing






