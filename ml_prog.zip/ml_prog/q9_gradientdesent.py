import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import SGDClassifier
from sklearn.metrics import r2_score
#data extraction
df=pd.read_csv('CO2_Emissions_Canada.csv')
df.info()
print(df.head(10))
print("press any key ")
print(df.describe())
print("press any key")
#descriptive statisctics
print(df.describe())
print("press any key")
featurset = df[['cylinder','enginsize','co2','fuelconsumption']]
featurset.hist()
plt.show()
print("non linear curve")
df_x1=df[['enginsize']]
df_y1=df[["co2"]]
plt.scatter(df_x1,df_y1,color="blue")
plt.xlabel("eEngine size()")
plt.ylabel("Co2 emisson(g/km)")
plt.show()
#train & test dataset division
x_train,x_test,y_train,y_test=train_test_split(df_x1,df_y1.values.ravel(),test_size=0.33,random_state=40)
#model fitting
clf=SGDClassifier(max_iter=1000)
clf.fit(x_train,y_train)
#model validation testing
test_y_hat1=clf.predict(x_test)
mse1=np.mean(np.absolute(test_y_hat1-y_test)**2)
print('mean square error is [0]:',format(mse1))
#print r2 score
r2score=r2_score(test_y_hat1,y_test)
print('r2 score is [0]',format(r2score))
#pred_x=input('Enter engine size to predict co2 emission ')
#print(clf.predict(pd.DataFrame({"enginsize":[pred_x]})))
