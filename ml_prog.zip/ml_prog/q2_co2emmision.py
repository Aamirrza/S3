import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn import linear_model
from sklearn.metrics import r2_score
#data extraction
df=pd.read_csv('CO2_Emissions_Canada.csv')
df.info()
print(df.head(10))
print("press any key ")
print(df.describe())
print("press any key")
#descriptive statisctics
print(df.describe())
print("press any key")
plt.scatter(df.enginsize,df.co2,color='blue')
plt.xlabel('Horse power')
plt.ylabel('Miles per gallon')
plt.show()
df_x=df[['enginsize']]
df_y=df[['co2']]
#train & test dataset division
x_train,x_test,y_train,y_test=train_test_split(df_x,df_y,test_size=0.33,random_state=40)
#model fitting
regr=linear_model.LinearRegression()
regr.fit(x_train,y_train)
print('coeficient',regr.coef_)
print('Intercept',regr.intercept_)
print('Singular',regr.singular_)
print('rank',regr.rank_)
#model validation testing
test_y_hat=regr.predict(x_test)
np.mean(np.absolute((test_y_hat-y_test)))
mse=np.mean((test_y_hat-y_test)**2)
print('mean square error is [0]:',format(mse))
#print r2 score
r2score=r2_score(test_y_hat,y_test)
print('r2 score is [0]',format(r2score))




