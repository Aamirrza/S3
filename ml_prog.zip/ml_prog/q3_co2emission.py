import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn import linear_model
from sklearn.metrics import r2_score
#data extraction
df=pd.read_csv('CO2_Emissions_Canada.csv')
df.info()
print(df.head(10))
print("press any key ")
print(df.describe())
print("press any key")
#descriptive statisctics
print(df.describe())
print("press any key")
featurset = df[['cylinder','enginsize','co2','fuelconsumption']]
fig,(ax1,ax2,ax3)=plt.subplots(1,3)
fig.suptitle('horizontally stacked subplots')
ax1.scatter(featurset.cylinder,featurset.co2,color='blue')
ax1.set(xlabel='cylinder',ylabel='co2Emission')
ax2.scatter(featurset.enginsize,featurset.co2,color='blue')
ax2.set(xlabel='enginesize',ylabel='co2')
ax3.scatter(featurset.fuelconsumption,featurset.co2,color='blue')
ax3.set(xlabel='fuel consumption',ylabel='co2')
fig.show()
df_x=df[['enginsize','cylinder','fuelconsumption']]
df_y=df[['co2']]
#train & test dataset division
x_train,x_test,y_train,y_test=train_test_split(df_x,df_y,test_size=0.33)
#model fitting
regr=linear_model.LinearRegression()
regr.fit(x_train,y_train)
print('coeficient',regr.intercept_)
#model validation testing
test_y_hat=regr.predict(x_test)
np.mean(np.absolute((test_y_hat-y_test)))

mse=np.mean((test_y_hat-y_test)**2)
print('mean square error is [0]:',format(mse))
#print r2 score
r2score=r2_score(test_y_hat,y_test)
print('r2 score is [0]',format(r2score))
print('co2 emission(intercept)',regr.intercept_)



