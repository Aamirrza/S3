import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn import linear_model
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import PolynomialFeatures
from sklearn.metrics import r2_score
#data extraction
df=pd.read_csv('CO2_Emissions_Canada.csv')
df.info()
print(df.head(10))
print("press any key ")
print(df.describe())
print("press any key")
#descriptive statisctics
print(df.describe())
print("press any key")
featurset = df[['cylinder','enginsize','co2','fuelconsumption']]
featurset.hist()
plt.show()
print("non linear curve")
df_x2=df[['fuelconsumption']]
df_y2=df[["co2"]]
poly_features=PolynomialFeatures(degree=2)
df_x2=poly_features.fit_transform(df_x2)
#train & test dataset division
x_train,x_test,y_train,y_test=train_test_split(df_x2,df_y2,test_size=0.33)
#model fitting
regr=linear_model.LinearRegression()
regr.fit(x_train,y_train)
print('coeficient',regr.intercept_)
#model validation testing
test_y_hat=regr.predict(x_test)
np.mean(np.absolute((test_y_hat-y_test)))

mse=np.mean((test_y_hat-y_test)**2)
print('mean square error is [0]:',format(mse))
#print r2 score
r2score=r2_score(test_y_hat,y_test)
print('r2 score is [0]',format(r2score))
print('co2 emission(intercept)',regr.intercept_)

