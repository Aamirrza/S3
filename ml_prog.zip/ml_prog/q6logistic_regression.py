import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_digits
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
digitdataset=load_digits()
print("image data shape",digitdataset.data.shape)
print("Label data shape",digitdataset.target.shape)
plt.figure(figsize=(20,4))
for index,(image,label) in enumerate(zip(digitdataset.data[0:5],digitdataset.target[0:5])):
                                     plt.subplot(1,5,index+1)
                                     plt.imshow(np.reshape(image,(8,8)),cmap=plt.cm.gray)
                                     plt.title('Label:%i\n'%label,fontsize=20)
plt.show()
x_train,x_test,y_train,y_test=train_test_split(digitdataset.data,digitdataset.target,test_size=0.32,random_state=42)
logisticregr=LogisticRegression(random_state=0,max_iter=10000)
logisticregr.fit(x_train,y_train)
prediction=logisticregr.predict(x_test)
score=logisticregr.score(x_test,y_test)
print("Accuracy score : ",score)
cm=metrics.confusion_matrix(y_test,prediction)
print("Confusion matrix is ")
print(cm)

