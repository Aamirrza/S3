from sklearn.cluster import KMeans
from sklearn import datasets
import matplotlib.pyplot as plt
from sklearn.metrics.cluster import homogeneity_score
from sklearn.cluster import AgglomerativeClustering
iris=datasets.load_iris()
x=iris.data;
y=iris.target

cluster=AgglomerativeClustering(n_clusters=3,linkage="average")
pred_y=cluster.fit_predict(x)
plt.scatter(x[pred_y==0,0],x[pred_y==0,1],s=100,c="red",label="iris_sentosa")
plt.scatter(x[pred_y==1,0],x[pred_y==1,1],s=100,c="blue",label="iris_versic")
plt.scatter(x[pred_y==2,0],x[pred_y==2,1],s=100,c="green",label="iris_verginica")
#plt.scatter(fest.cluster_centers_[:,0],fest.cluster_centers_[:,1],s=100,c="yellow",label="centroids")
plt.legend()
plt.show()
print("score",homogeneity_score(y,pred_y))
