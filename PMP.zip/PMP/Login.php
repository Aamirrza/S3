<?php
    include("DBcon.php");
    SESSION_START();

    if(isset($_POST["btnLogin"]))
    {
      $type1=$_POST["type1"];
      //$type=$_POST["type1"];
     // echo  $type;
      //echo  $type1;
     

      if($type1=="Student"){
        echo "Student";
        $em=$_POST["txtEmailID"];
        $pwd=$_POST["txtPassword"];
        $query="SELECT * FROM studentmaster where EmailID='$em' AND Password='$pwd'";
        $res=mysqli_query($con,$query);
       
        while($row=mysqli_fetch_row($res)){
            if(strcmp($em,$row[2]==0) && strcmp($pwd,$row[3]==0))
            {
              $_SESSION["StudentID"]=$row[0];
                header("Location:StudentSite/Dashboard.php");
            }
        }
      }
      else if($type1=="Faculty"){
        echo "Faculty";
        $em=$_POST["txtEmailID"];
        $pwd=$_POST["txtPassword"];
        $query="SELECT * FROM facultymaster where EmailID='$em' AND Password='$pwd'";
        $res=mysqli_query($con,$query);
       
        while($row=mysqli_fetch_row($res)){
            if(strcmp($em,$row[3]==0) && strcmp($pwd,$row[5]==0))
            {
                $_SESSION["FacultyID"]=$row[0];
                header("Location:FacultySite/Dashboard.php");
            }
        }
      }
      else{
        echo"invalid data";
      }
        
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="bootstrap/bootstrap-5.0.2-dist/css/bootstrap.min.css">
</head>
<!-- style="background-image: url(Image/LoginImage.jpg);" -->

<body style="background-image: url(Image/LoginImage.jpg);">

  <div class="modal modal-sheet position-static d-block" tabindex="-1" role="dialog" id="modalSheet"
    style="padding-top: 10rem;">

    <div class="modal-dialog" role="document">
      <div class="modal-content rounded-4 shadow">
        <div class="modal-header border-bottom-0">
          <h1 class="modal-title fs-4 "><b>Login</b></h1>
          <!-- <button type="button" class="btn-close" data-bs-dismiss="modal" style="padding-top: 10rem;" aria-label="Close"></button> -->
        </div>
        <form method="Post">
          <div class="modal-body py-0">
            <div class="mb-3">
              <label for="exampleFormControlInput1" class="form-label">Email ID</label>
              <input type="Text" class="form-control" id="exampleFormControlInput1" placeholder="Email ID"
                name="txtEmailID">
            </div>
            <div class="mb-3">
              <label for="exampleFormControlInput1" class="form-label">Password</label>
              <input type="Password" class="form-control" id="exampleFormControlInput1" placeholder="Password"
                name="txtPassword">
            </div>
            <!-- <div class="mb-3">
              <label for="exampleFormControlInput1" class="form-label">Type</label>
              <select class="form-select" aria-label="Default select example" name="Type">
                <option selected>--SELECT--</option>
                <option value="1">Student</option>
                <option value="2">Faculty</option>
              </select>
            </div> -->
            <div class="mb-3">
              <label for="exampleFormControlInput1" class="form-label">Type</label> &nbsp&nbsp
              <input class="form-check-input" type="radio" name="type1" value="Student">
              <label class="form-check-label" for="flexRadioDefault1">
                Student
              </label>
              <input class="form-check-input" type="radio" name="type1" value="Faculty">
              <label class="form-check-label" for="flexRadioDefault1">
                Faculty
              </label>
              </select>
            </div>
          </div>
          <div class="modal-footer flex-column align-items-stretch w-100 gap-2 pb-3 border-top-0">
            <input type="submit" value="Login" name="btnLogin" class="btn btn-lg btn-primary" />
          </div>
        </form>
      </div>
    </div>
  </div>


</body>

</html>