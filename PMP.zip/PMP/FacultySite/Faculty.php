<?php
//$_SESSION
 include("DBcon.php");
$FacultyID="";
$nm="";
$en="";
$em="";
$mn="";
$pwd="";

 if(isset($_POST["btnSubmit"]))
 {
  // if($FacultyID!="")
  // {
  //     echo "Update";
  //   $nm=$_POST["txtFacultyName"];
  //   $en=$_POST["txtEnrollmentNo"];
  //   $em=$_POST["txtEmailid"];
  //   $mn=$_POST["txtMobileNo"];
  //   $pwd=$_POST["txtPassword"];
  //   $q="UPDATE facultymaster SET FacultyName='$nm',EnrollmentNo='$en',EmailID='$em',MobileNo='$mn',Password='$pwd' WHERE FacultyID='$FacultyID' ";
  //   $r=mysqli_query($con,$q);
  // }
  // else{
    $nm=$_POST["txtFacultyName"];
    $en=$_POST["txtEnrollmentNo"];
    $em=$_POST["txtEmailid"];
    $mn=$_POST["txtMobileNo"];
    $pwd=$_POST["txtPassword"];
    //$pwd=$_POST["txtPassword"];
    $q="INSERT INTO facultymaster(FacultyName,EnrollmentNo,EmailID,MobileNo,Password)VALUES('$nm','$en','$em','$mn','$pwd')";
    $r=mysqli_query($con,$q);
  //}
 }

 if(isset($_POST["btnUpdate"]))
 {
  
      // echo "Update";
      // $FacultyID=$_GET["FacultyID"];
      // echo $FacultyID;
    $nm=$_POST["txtFacultyName"];
    $en=$_POST["txtEnrollmentNo"];
    $em=$_POST["txtEmailid"];
    $mn=$_POST["txtMobileNo"];
    $pwd=$_POST["txtPassword"];
    $q="UPDATE facultymaster SET FacultyName='$nm',EnrollmentNo='$en',EmailID='$em',MobileNo='$mn',Password='$pwd' WHERE FacultyID='$FacultyID' ";
    $r=mysqli_query($con,$q);
   
 }

 if($_REQUEST["action"]=="edit")
  {
    $FacultyID=$_GET["FacultyID"];
   // echo $FacultyID;
    $q="SELECT * FROM facultymaster WHERE FacultyID=$FacultyID";

     $r=mysqli_query($con,$q);
     while($row=mysqli_fetch_assoc($r))
            {
              $nm=$row["FacultyName"];
              $en=$row["EnrollmentNo"];
              $em=$row["EmailID"];
              $mn=$row["MobileNo"];
              $pwd=$row["Password"];
            }
  }
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Faculty Page</title>
  <script src="../Admin Site/color-modes.js"></script>
  <link rel="stylesheet" href="../bootstrap/bootstrap-5.0.2-dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../Admin Site/dashboard.css">

  <style>
    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }

    .b-example-divider {
      width: 100%;
      height: 3rem;
      background-color: rgba(0, 0, 0, .1);
      border: solid rgba(0, 0, 0, .15);
      border-width: 1px 0;
      box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
    }

    .b-example-vr {
      flex-shrink: 0;
      width: 1.5rem;
      height: 100vh;
    }

    .bi {
      vertical-align: -.125em;
      fill: currentColor;
    }

    .nav-scroller {
      position: relative;
      z-index: 2;
      height: 2.75rem;
      overflow-y: hidden;
    }

    .nav-scroller .nav {
      display: flex;
      flex-wrap: nowrap;
      padding-bottom: 1rem;
      margin-top: -1px;
      overflow-x: auto;
      text-align: center;
      white-space: nowrap;
      -webkit-overflow-scrolling: touch;
    }

    .btn-bd-primary {
      --bd-violet-bg: #712cf9;
      --bd-violet-rgb: 112.520718, 44.062154, 249.437846;

      --bs-btn-font-weight: 600;
      --bs-btn-color: var(--bs-white);
      --bs-btn-bg: var(--bd-violet-bg);
      --bs-btn-border-color: var(--bd-violet-bg);
      --bs-btn-hover-color: var(--bs-white);
      --bs-btn-hover-bg: #6528e0;
      --bs-btn-hover-border-color: #6528e0;
      --bs-btn-focus-shadow-rgb: var(--bd-violet-rgb);
      --bs-btn-active-color: var(--bs-btn-hover-color);
      --bs-btn-active-bg: #5a23c8;
      --bs-btn-active-border-color: #5a23c8;
    }

    .bd-mode-toggle {
      z-index: 1500;
    }
  </style>

  <!-- <link rel="stylesheet" href="../bootstrap/bootstrap-5.0.2-dist/css/"> -->

</head>

<body>
<?php include("Hearder.php")?>

  <div class="container-fluid">
    <div class="row">
    <?php include("sidebar.php")?>

      <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div
          class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
          <h1 class="h2">Dashboard</h1>
          <div class="btn-toolbar mb-2 mb-md-0">
            <!-- <div class="btn-group me-2">
            <button type="button" class="btn btn-sm btn-outline-secondary">Share</button>
            <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
          </div>
          <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle d-flex align-items-center gap-1">
            <svg class="bi"><use xlink:href="#calendar3"></use></svg>
            This week
          </button> -->
          </div>
        </div>


        
        <div class="card p-3">
          <h2>Faculty Data</h2>
          <hr>
          <form action="" method="POST">
            <div class="mb-3">
              <label for="formGroupExampleInput" class="form-label">Faculty Name</label>
              <input type="text" class="form-control" id="formGroupExampleInput"
                placeholder="Faculty Name" name="txtFacultyName" value="<?php echo $nm?>">
            </div>
            <div class="mb-3">
              <label for="formGroupExampleInput2" class="form-label">Enrollment No</label>
              <input type="text" class="form-control" id="formGroupExampleInput2"
                placeholder="Enrollment No" name="txtEnrollmentNo" value="<?php echo $en?>">
            </div>
            <div class="mb-3">
              <label for="formGroupExampleInput2" class="form-label">Email ID</label>
              <input type="text" class="form-control" id="formGroupExampleInput2"
                placeholder="EmailID" name="txtEmailid" value="<?php echo $em?>">
            </div>
            <div class="mb-3">
              <label for="formGroupExampleInput2" class="form-label">Mobile No</label>
              <input type="text" class="form-control" id="formGroupExampleInput2"
                placeholder="Mobile No" name="txtMobileNo" value="<?php echo $mn?>">
            </div>
            <div class="mb-3">
              <label for="formGroupExampleInput2" class="form-label">Password</label>
              <input type="text" class="form-control" id="formGroupExampleInput2"
                placeholder="Password" name="txtPassword" value="<?php echo $pwd?>">
            </div>
            <div class="mb-3">
              <label for="formGroupExampleInput2" class="form-label">Faculty Image</label>
              <input type="file" class="form-control" id="formGroupExampleInput2"
                 name="fuimage">
            </div>
            <div >
            <input type="submit" class="btn btn-primary" id="formGroupExampleInput2"
                 name="btnSubmit" value="Save">
                 <input type="submit" class="btn btn-primary" id="formGroupExampleInput2"
                 name="btnUpdate" value="Update">
                 <input type="reset" class="btn btn-secondary" id="formGroupExampleInput2"
                 name="btnSubmit" value="reset">
            </div>
          </form>
<br>
          <?php
              $q="SELECT * FROM facultymaster";
              $r=mysqli_query($con,$q);
            ?>

          <table class="table table-striped">
            <tr>
              <td>FacultyName</td>
              <td>EnrollmentNo</td>
              <td>EmailID</td>
              <td>MobileNo</td>
              <td>Password</td>
              <td>Action</td>
            </tr>
            <?php
            while($row=mysqli_fetch_assoc($r))
            {
              ?>
              <tr>
                <td><?php echo $row['FacultyName']?></td>
                <td><?php echo $row['EnrollmentNo']?></td>
                <td><?php echo $row['EmailID']?></td>
                <td><?php echo $row['MobileNo']?></td>
                <td><?php echo $row['Password']?></td>
                <!-- <input type="submit" id="formGroupExampleInput2"
                 name="btnUpdate" value="Update"> -->
                 <td>
                 <a class="btn btn-success" href="Faculty.php?action=edit&FacultyID=<?php echo $row['FacultyID']?>" > Edit</a>
                 <a class="btn btn-danger" > Delete</a>
                 </td>
                 <!-- <input type="submit" class="btn btn-danger" id="formGroupExampleInput2"
                 name="btnDelete" value="Delete"> -->
              </tr>
              <?php
            }
                
            ?>
            
          </table>
        </div>
      </main>
    </div>
  </div>

  <!-- <script src="/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script> -->
  <script src="../bootstrap/bootstrap-5.0.2-dist/js/bootstrap.bundle.min.js">

  </script>
</body>

</html>