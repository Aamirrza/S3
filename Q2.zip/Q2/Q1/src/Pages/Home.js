import React, { useEffect } from 'react'
import { useState } from 'react'
import axios from 'axios'

const Home = () => {

  useEffect(() => {
    FillData()
    FillAllBlogtype()
  }, [])

  const [data, setdata] = useState([]);
  const [allBlogtype, setallBlogtype] = useState([]);

  async function FillData() {
    const res = await axios.get("http://localhost:1920/BlogMaster/DisplayBlog")
    setdata(res.data);
  }

  async function FillAllBlogtype() {
    const res = await axios.get("http://localhost:1920/BlogMaster/GetBlogType")
    setallBlogtype(res.data);
  }

  async function FillDataByBlogtype(BlogType) {
    const res = await axios.get("http://localhost:1920/BlogMaster/GetBlogByType/"+BlogType)
    setdata(res.data);
  }

  return (
    <div>
      <h1>Home Page</h1>
      <table>
        <tr>
          {
            allBlogtype.map(item => {
              return (
                <a onClick={()=>FillDataByBlogtype(item)}><td>{item}</td></a>
              )
            })
          }
        </tr>
      </table>
      {
        data.map(Blog => {
          return (
            <div class="card" >
              <div class="card-body">
                <h5 class="card-title">{Blog.BlogType}</h5>
                <h6 class="card-subtitle mb-2 text-body-secondary">{Blog.BlogName}</h6>
                <p class="card-text">{Blog.Description}</p>
              </div>
            </div>
          )
        })

      }
    </div>

  )
}

export default Home
