import React, { useEffect, useState } from 'react'
import { GetData, GetBlogByType, GetBlogType } from '../Component/BlogSlice';
import { useSelector, useDispatch } from 'react-redux'
import axios from 'axios'


const Home = () => {
  const [vbdata,setvbdata]=useState([]);
  const [vbtdata,setvbtdata]=useState([]);

  const dispatch = useDispatch();

  useEffect(() => {
   // dispatch(GetData())
    //dispatch(GetBlogType())
    FillData();
    FillAllBlogtype()
    console.log(Blogdata);
    console.log(BlogType);
  }, [])

  const Blogdata = useSelector(state => state.blog.Blogdata);
  const BlogType = useSelector(state => state.blog.BlogTypedata);

  async function FillData() {
    const res = await axios.get("http://localhost:1920/BlogMaster/DisplayBlog")
    setvbdata(res.data);
  }

  async function FillAllBlogtype() {
    const res = await axios.get("http://localhost:1920/BlogMaster/GetBlogType")
    setvbtdata(res.data);
  }


  return (
    <div>
      <h1>Home Page</h1>
      <table>
        <tr>
          {
            vbtdata.map(item => {
              return (
                <a onClick={() => dispatch(GetBlogByType({ item }))}><td>{item}</td></a>
              )
            })
          }
        </tr>
      </table>
      <div>
        {
          vbdata.length > 0 && vbdata.map(b => {
            return (
              <div class="card col-md-6">
                <div class="card-body ">
                  <h5 class="card-title">{b.BlogType}</h5>
                  <h6 class="card-subtitle mb-2 text-body-secondary">{b.Description}</h6>
                  <p class="card-text">{b.BlogName}</p>
                </div>
              </div>
            )
          })

        }
      </div>
    </div>

  )
}

export default Home
