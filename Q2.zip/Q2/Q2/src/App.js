import './App.css';
import NavBar from './Component/NavBar';
import { Routes,Route } from 'react-router';
import Home from './Pages/Home';
import Blog from './Component/Blog';
// import Blog from './Pages/Blog';
// import { useState } from 'react';

function App() {

    return (
    <div className="App">
        <NavBar>
        </NavBar>
        <>
          <Routes>
            <Route path='/' element={<Home/>} />
            <Route path='/Blog' element={<Blog/>} />
          </Routes>
        </>
    </div>
  );
}

export default App;
