import React from 'react'
import { useState } from 'react'
import { AddData } from './BlogSlice';
import { useDispatch } from 'react-redux';
import axios from 'axios'

const Blog = () => {
  const dispatch = useDispatch();

  const [BlogType, setBlogType] = useState("");
  const [Description, setDescription] = useState("");
  const [BlogName, setBlogName] = useState("");
  // const d = useSelector((state) => state.blog)

  function onSubmited(event) {
    event.preventDefault();
    dispatch(AddData({BlogType,Description,BlogName}))

    // var data={BlogType,Description,BlogName}
    // const insert =axios.post("http://localhost:1920/BlogMaster/AddBlog",data)
    // if(insert)
    //   alert('Inserted...')

    setBlogType("");
    setDescription("");
    setBlogName("");

    }
    
  return (
    <div>
      <h1>Blog</h1>
      <form onSubmit={onSubmited}>
        <div class="mb-3">
          <label class="form-label">BlogType</label>
          <input type="text" class="form-control" onChange={event => setBlogType(event.target.value)} value={BlogType} />
        </div>
        <div class="mb-3">
          <label class="form-label">Description</label>
          <textarea class="form-control" onChange={event => setDescription(event.target.value)} value={Description}></textarea>
          {/* <input type="text" class="form-control" id="formGroupExampleInput2" placeholder="Another input placeholder"/> */}
        </div>
        <div class="mb-3">
          <label class="form-label">BlogName</label>
          <input type="text" class="form-control" onChange={event => setBlogName(event.target.value)} value={BlogName} />
        </div>
        <div class="mb-3">
          <button class="btn btn-primary"> Submit </button>
        </div>
      </form>
    </div>
  )
}

export default Blog
