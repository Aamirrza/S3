import {configureStore} from '@reduxjs/toolkit'

import BlogSlice  from '../Component/BlogSlice'

export const Store = configureStore(
    {
        reducer: {
            blog : BlogSlice
        }
    }
)