const mongoose = require("mongoose")
const blog=new mongoose.Schema({

    BlogType:{
        type:String
    },
    BlogName:{
        type:String
    },
    Description:{
        type:String
    }
})
module.exports=mongoose.model('BlogMaster',blog);
