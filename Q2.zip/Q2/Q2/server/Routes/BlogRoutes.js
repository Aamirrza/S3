const express = require("express")
const router = express.Router();
const bloginfo = require('../Models/BlogSchema')

router.post('/AddBlog', async (req, res) => {
    try {
        const rb = req.body;
        const blogdata = await new bloginfo(
            {
                BlogType: rb.BlogType,
                BlogName: rb.BlogName,
                Description: rb.Description
            }
        )
        blogdata.save();
    } catch (error) {
        console.log(error);
    }
})

router.get('/DisplayBlog', async (req, res) => {
    const data = await bloginfo.find();
    res.json(data);
})

router.get('/GetBlogType', async (req, res) => {
    const data = await bloginfo.distinct('BlogType');
    res.json(data);
})

router.get('/GetBlogByType/:BlogType', async (req, res) => {
    const data = await bloginfo.find({ BlogType: req.params.BlogType });
    res.json(data);
})

module.exports = router;