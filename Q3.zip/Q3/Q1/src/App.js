import './App.css';
import Bill from './Component/Bill';

function App() {
  return (
    <div className="App">
      <Bill></Bill>
    </div>
  );
}

export default App;
