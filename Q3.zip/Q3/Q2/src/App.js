import './App.css';
import Billing from './Component/Billing';

function App() {
  return (
    <div className="App">
      <Billing></Billing>
    </div>
  );
}

export default App;
