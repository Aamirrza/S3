import {useDispatch} from 'react-redux'
import { useEffect, useState } from 'react'
import axios from 'axios'
import {AddData } from './CounterSlice'

export const Billing = () => {

    // const pcount = useSelector((state) => state.counter.value)
    // const bcount = useSelector((state) => state.counter.value1)
    const dispatch = useDispatch()

  const [Name, setName] = useState("");
  const [MobileNo, setMobileNo] = useState("");
  const [Product, setProduct] = useState([]);
  const [Data, setData] = useState([])
  
  useEffect(()=>{
    Filldata();
    FillBilldata()
  },[])

  async function FillBilldata() {
    const res = await axios.get("http://localhost:1920/ProductMaster/DisplayBill")
    setData(res.data);
  }

  function addQty(id) {
    var data = Product.map(item => {
      if (item.id == id) {
        item.qty += 1
      }
      return item
    })
    setProduct(data)
  }
  function subQty(id) {
    var data = Product.map(item => {
      if (item.id == id && item.qty > 0) {
        item.qty -= 1
      }
      return item
    })
    setProduct(data)
  }

  function onSubmited() {
    var data = { Name, MobileNo, BillData: Product }
    dispatch(AddData(data))
    alert(Name)

    setName("");
    setMobileNo("");
    //setProduct([]);

    }

  async function Filldata() {
    const res = await axios.get("http://localhost:1920/ProductMaster/DisplayProduct")
    var cnt = 1;
    var data = res.data.map(item => {
      return { ...item, qty: 0, id: cnt++ }
    })
    setProduct(data);
  }

  return (
    <div>
        <h2>BILLING SYSTEM</h2><hr/>
        {/* <h2>Pizza Price(300)</h2>
        <button aria-label='Decrement value' onClick={() => dispatch(pdecrement())}>Decrement</button>
        <span>{pcount}</span>
        <button aria-label='Increment value' onClick={() => dispatch(pincrement())}>Increment</button>
        <h3>Pizza Total : {pcount *300} </h3>
        <br></br>
        <h2>Burger Price(100)</h2>
        <button aria-label='Decrement value' onClick={() => dispatch(bdecrement())}>Decrement</button>
        <span>{bcount}</span>
        <button aria-label='Increment value' onClick={() => dispatch(bincrement())}>Increment</button>
        <h3>Burger Total : {bcount *100} </h3><hr/>
        <h2>Net Amount : {(pcount*300)+(bcount*100)}</h2> */}
        {
        Product.map(item => {
          return (
            <div>
              <h2>{item.Name}</h2>
              <input type='button' value="-" onClick={() => subQty(item.id)}></input>
              {item.qty}
              <input type='button' value="+" onClick={() => addQty(item.id)}></input>
              <h3>{item.Name} Amount : {item.qty * +item.Price}</h3>
            </div>
          )
        })

      }
      <h3>{Product.length > 0 ? Product.reduce((a, b) => { return a + (+b.Price * b.qty) }, 0) : 0}</h3>
        <hr/>
        <label>Name</label>
      <input type='Text' onChange={event => setName(event.target.value)}></input>
      <br></br>
      <label>MobileNo</label>
      <input type='Text' onChange={event => setMobileNo(event.target.value)}></input>
      <br></br>
      <input type='button' value="Save Data" onClick={()=>onSubmited()}></input>
      <br></br>
      <table border={1}>
        <tr>
          {
            Data.map(item => {
              return (
                <div>
                  <td>{item.Name}</td>
                  <td>{item.MobileNo}</td>
                  <td><table>{item.BillData.map(bd => {
                    return (

                      <tr>
                        <td>{bd.Name}</td>
                        <td>{bd.Price}</td>
                        <td>{bd.qty}</td>
                        <td>{+bd.Price * bd.qty}</td>
                      </tr>

                    )
                  })}
                  <tr>
                      <td colSpan={3}>Total</td>
                      <td>{item.BillData.length > 0 ? item.BillData.reduce((a, b) => { return a + (+b.Price * b.qty) }, 0) : 0}</td>
                    </tr>
                  </table></td>
                </div>
              )
            })
          }
        </tr>
      </table>
    </div>
  )
}

export default Billing
