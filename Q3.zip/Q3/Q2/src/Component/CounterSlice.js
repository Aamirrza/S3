import {createSlice} from '@reduxjs/toolkit'
import axios from 'axios'

// const initialState = {
//     value :0,
//     value1:0
// }

export const CounterSlice = createSlice({
    name : 'counter',
    initialState:[],
    reducers : {
        // pincrement : (state) => {
        //     state.value +=1
        // },
        // pdecrement : (state) => {
        //     state.value -=1
        // },
        // bincrement : (state) => {
        //     state.value1 +=1
        // },
        // bdecrement : (state) => {
        //     state.value1 -=1
        // }
        AddData:async(state,action)=>{
            let insert= await axios.post("http://localhost:1920/BillMaster/AddBill",action.payload);
            if(insert)
                alert("Inserted");
            return state;
        }
    }
})

// export const {pincrement,pdecrement,bincrement,bdecrement} = CounterSlice.actions
export const {AddData} = CounterSlice.actions
export default CounterSlice.reducer


