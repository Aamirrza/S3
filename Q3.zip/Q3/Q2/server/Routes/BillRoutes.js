const express = require("express")
const router = express.Router();
const productinfo = require('../Models/ProductSchema')
const billinfo = require('../Models/BillSchema')

router.post('/AddProduct', async (req, res) => {
    try {
        const rb = req.body;
        const productdata = await new productinfo(
            {
                Name: rb.Name,
                Price: rb.Price
            }
        )
        productdata.save();
    } catch (error) {
        console.log(error);
    }
})

router.get('/DisplayProduct', async (req, res) => {
    const data = await productinfo.find();
    res.json(data);
})


router.post('/AddBill', async (req, res) => {
    try {
        const rb = req.body;
        const billdata = await new billinfo(
            {
                Name: rb.Name,
                MobileNo: rb.MobileNo,
                BillData: rb.BillData
            }
        )
        billdata.save();
    } catch (error) {
        console.log(error);
    }
})

router.get('/DisplayBill', async (req, res) => {
    const data = await billinfo.find();
    res.json(data);
})

module.exports = router;