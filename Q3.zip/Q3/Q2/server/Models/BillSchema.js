const mongoose = require("mongoose")
const Bill=new mongoose.Schema({

    Name:{
        type:String
    },
    MobileNo:{
        type:String
    },
    BillData:{
        type:Array
    }
})
module.exports=mongoose.model('BillMaster',Bill);
