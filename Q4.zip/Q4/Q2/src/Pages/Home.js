import { React, useState, useEffect } from 'react'
import { useDispatch } from "react-redux"
import { addtocart } from '../redux/ShopSlice'
import axios from "axios";

const Home = () => {
  const [Products, SetProducts] = useState([]);
  const dispatch = useDispatch();

  useEffect(() => {
    async function fetchdata() {
      // var result = await fetch("data.json");
      var res = await axios.get('http://localhost:1920/ProductMaster/DisplayProduct');
      var cnt = 1;
      var data = res.data.map(item => {
        return { ...item, qty: 0, id: cnt++ }
      })
      SetProducts(data);
    }
    fetchdata();
  }, [])

  return (
    <div className='container-fluid row'>
      {
        Products.length > 0 && Products.map(item => {
          return (
            <div class="col-lg-3 mb-3">
              <div class="card">
                <img class="card-img-top" src={item.ProductImage} alt="Title" style={{ height: "300px" }} />
                <div class="card-body">
                  <h4 class="card-title">{item.Name}</h4>
                  <p class="card-text">{item.Price}</p>
                  <p class="card-text"><button type="button" class="btn btn-primary" onClick={() => dispatch(addtocart(item))}>Add to Cart</button></p>
                </div>
              </div>
            </div>
          )
        })
      }
    </div>
  )
}

export default Home
