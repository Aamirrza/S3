import React from 'react'
import { useSelector, useDispatch } from 'react-redux'
import {inc,dec,del} from '../redux/ShopSlice'

function Cart() {
  const cartdata = useSelector(state => state.shop);
  const dispatch =useDispatch();

  const total=()=>{
    let total=0;
    cartdata.forEach(element => {
      total+=element.Price*element.qty;
    })
    return total;
   }

  return (
    <div>
      <div class="table-responsive">
        <table class="table table-primary">
          <thead>
            <tr>
              <th>Name</th>
              <th>Image</th>
              <th>Quantity</th>
              <th>Price</th>
              <th>Subtotal</th>
              <th>Remove</th>
            </tr>
          </thead>
          <tbody>
            {cartdata.length > 0 && cartdata.map(item => {
              return (<tr>
                <td>{item.Name}</td>
                <td><img src={item.ProductImage} class="img-fluid rounded-top" alt=""/></td>
                <td><button type="button" class="btn btn-primary" onClick={()=>dispatch(inc(item.id))}>+</button>{item.qty}
                <button type="button" class="btn btn-primary" onClick={()=>dispatch(dec(item.id))}>-</button></td>
                <td>{item.Price}</td>
                <td>{(item.qty * item.Price).toFixed(2)}</td>
                <td><button type="button" class="btn btn-primary" onClick={()=>dispatch(del(item.id))}>Remove</button></td>
              </tr>)
            })}
          </tbody>
        </table>
      </div>
            <h3>Total Is :{total()}</h3>
    </div>
  )
}

export default Cart
