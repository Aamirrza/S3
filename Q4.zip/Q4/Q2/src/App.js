import './App.css';
import NavBar from './Component/NavBar';
import { Routes,Route } from 'react-router';
import Home from './Pages/Home';
import Cart from './Pages/Cart';

function App() {
  return (
    <div className="App">
        <NavBar/>
        <>
          <Routes>
            <Route path='/' element={<Home/>} />
            <Route path='/cart' element={<Cart/>} />
          </Routes>
        </>
    </div>
  );
}

export default App;
