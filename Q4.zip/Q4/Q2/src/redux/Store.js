import { configureStore } from "@reduxjs/toolkit";
import reducer from "./ShopSlice"

const Store = configureStore({
    reducer:{
        shop:reducer
    }
})

export default Store;