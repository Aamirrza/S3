import { createSlice } from '@reduxjs/toolkit'

const initialState = []

export const ShopSlice = createSlice({
    name: 'shop',
    initialState,
    reducers: {
        addtocart: (state, action) => {
            var newitem = action.payload;
            var flag = false;
            state.forEach(item => {
                if (item.id === newitem.id) {
                    item.qty += 1;
                    flag = true;
                }
            })
            if (!flag) {
                newitem.qty = 1;
                state.push(newitem);
            }
            return state;
        },
        inc: (state, action) => {
            state.forEach(item => {
                if (item.id === action.payload) {
                    item.qty += 1;
                }
            })
            return state;
        },
        dec: (state, action) => {
            state.forEach(item => {
                if (item.id === action.payload && item.qty > 1) {
                    item.qty -= 1;
                }
            })
            return state;
        }, del: (state, action) => {
            return state.filter(item => item.id !== action.payload)
        }
    }
})

export const { addtocart,inc,dec,del } = ShopSlice.actions

export default ShopSlice.reducer