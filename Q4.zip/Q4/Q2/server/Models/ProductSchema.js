const mongoose = require("mongoose")
const Product=new mongoose.Schema({

    Name:{
        type:String
    },
    ProductImage:{
        type:String
    },
    Price:{
        type:Number
    }
})
module.exports=mongoose.model('ProductMaster',Product);
