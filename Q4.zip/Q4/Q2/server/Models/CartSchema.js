const mongoose = require("mongoose")
const Cart=new mongoose.Schema({

    Name:{
        type:String
    },
    MobileNo:{
        type:String
    },
    CartData:{
        type:Array
    }
})
module.exports=mongoose.model('CartMaster',Cart);
