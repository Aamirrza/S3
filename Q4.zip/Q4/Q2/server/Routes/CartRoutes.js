const express = require("express")
const router = express.Router();
const productinfo = require('../Models/ProductSchema')
const cartinfo = require('../Models/CartSchema')

router.post('/AddProduct', async (req, res) => {
    try {
        const rb = req.body;
        const productdata = await new productinfo(
            {
                Name: rb.Name,
                ProductImage:rb.ProductImage,
                Price: rb.Price
            }
        )
        productdata.save();
    } catch (error) {
        console.log(error);
    }
})

router.get('/DisplayProduct', async (req, res) => {
    const data = await productinfo.find();
    res.json(data);
})


router.post('/AddCartData', async (req, res) => {
    try {
        const rb = req.body;
        const cartdata = await new cartinfo(
            {
                Name: rb.Name,
                MobileNo: rb.MobileNo,
                CartData: rb.CartData
            }
        )
        cartdata.save();
    } catch (error) {
        console.log(error);
    }
})

router.get('/DisplayCartData', async (req, res) => {
    const data = await cartinfo.find();
    res.json(data);
})

module.exports = router;