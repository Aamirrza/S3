import './App.css';
import NavBar from './Component/NavBar';
import { Routes, Route } from 'react-router';
import Home from './Pages/Home';
import Cart from './Pages/Cart';
import { React, useState, useEffect } from 'react'
import axios from "axios";

function App() {

  const [Data, SetData] = useState([]);
  const [CartData, SetCartData] = useState([]);

  async function fetchdata() {
    var res = await axios.get('http://localhost:1920/ProductMaster/DisplayProduct');
    // var json = await result.json();
    var cnt = 1;
    var data = res.data.map(item => {
      return { ...item, qty: 0, id: cnt++ }
    })
    SetData(data);
  }

  useEffect(() => {
    fetchdata();
  }, [])

  return (
    <div className="App">
      <NavBar />
      <>
        <Routes>
          <Route path='/' element={<Home data={Data} setdata={SetCartData} cartdata={CartData} />} />
          <Route path='/cart' element={<Cart setdata={SetCartData} cartdata={CartData} />} />
        </Routes>
      </>
    </div>
  );
}

export default App;
