import { React } from 'react'

const Home = (props) => {

  const addtocart = (newitem) => {
    var flag =false;
    var data = props.cartdata.map(item =>{
      if(item.id===newitem.id){
        item.qty+=1;
        flag=true;
      }
      return item;
    });
    if(!flag){
      newitem.qty=1;
      props.setdata(props.cartdata.concat(newitem))
    }else{
      props.setdata(data)
    }

  }

  return (
    <div className='container-fluid row'>
      {
       props.data.map(item => {
          return (
            <div class="col-lg-3 mb-3">
              <div class="card">
                <img class="card-img-top" src={item.ProductImage} alt="Title" style={{height:"300px"}} />
                <div class="card-body">
                  <h4 class="card-title">{item.Name}</h4>
                  <p class="card-text">{item.Price}</p>
                  <p class="card-text"><button type="button" class="btn btn-primary" onClick={()=>addtocart(item)}>Add to Cart</button></p>
                </div>
              </div>
            </div>
          )
        })
      }
    </div>
  )
}

export default Home
