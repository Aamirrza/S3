import React, { useEffect, useState } from 'react'


function Cart(props) {

  useEffect(()=>{
    filldata()
  },[])
  
  async function filldata()
  {

  }

  const total = () => {
    let total = 0;
    props.cartdata.forEach(element => {
      total += element.Price * element.qty;
    })
    return total;
  }

  const dec = (id) => {
    const cdata = props.cartdata.map(item=>{
      if (item.id === id && item.qty > 1) {
        item.qty -= 1;
      }
      return item;
    });
    props.setdata(cdata)
  }

  const inc = (id) => {
    //alert(id)
    //console.log(cartdata)
    const cdata = props.cartdata.map(item => {
   // alert(item.id)
    console.log(props.cartdata)
      if (item.id === id) {
        item.qty += 1;
      }
      return item;
    });
    props.setdata(cdata)
  }

  const del = (id) => {
    const cdata = props.cartdata.filter(item => item.id !== id)
    props.setdata(cdata)
  }
  return (
    <div>
      <div class="table-responsive">
        <table class="table table-primary">
          <thead>
            <tr>
              <th>Title</th>
              <th>Image</th>
              <th>Quantity</th>
              <th>Price</th>
              <th>Subtotal</th>
              <th>Remove</th>
            </tr>
          </thead>
          <tbody>
            {props.cartdata.map(item => {
              return (<tr>
                <td>{item.id}</td>
                <td>{item.Name}</td>
                <td><img src={item.ProductImage} class="img-fluid rounded-top" alt="" style={{height:"250px"}} /></td>
                <td><button type="button" class="btn btn-primary" onClick={() => inc(item.id)}>+</button>{item.qty}
                  <button type="button" class="btn btn-primary" onClick={() => dec(item.id)}>-</button></td>
                <td>{item.Price}</td>
                <td>{(item.qty * item.Price).toFixed(2)}</td>
                <td><button type="button" class="btn btn-primary" onClick={() => del(item.id)}>Remove</button></td>
              </tr>)
            })}
          </tbody>
        </table>
      </div>
      <div>Total is {total()}</div>

    </div>
  )
}

export default Cart
