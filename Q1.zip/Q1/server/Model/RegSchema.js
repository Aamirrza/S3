const mongoose = require("mongoose");


const RegSchema = new mongoose.Schema({
    Name:{
        type:String,
        require:[true,"Please Enter Student Name"]
    }, 
    Email:{
        type:String,
        require:[true,"Please Enter Student Email"]
    },
    Mobileno:{
        type:String,
        require:[true,"Please Enter Student Mobileno"]
    },
    Address:{
        type:String,
        require:[true,"Please Enter Student Address"] 
    },
    Dob:{
        type:String,
        require:[true,"Please Enter Student Dob"]
    },
    City:{
        type:String,
        require:[true,"Please Enter Student City"]
    },
    Hobbies:{
        type:String,
        require:[true,"Please Enter Student Hobbies"]
    }
 })

module.exports = mongoose.model('RegForm',RegSchema);