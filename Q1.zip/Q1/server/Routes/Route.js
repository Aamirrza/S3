const express = require("express");
const Regdata = require("../Model/RegSchema");
const route = express.Router();

route.post('/RegRoute', (req, res) => {

    const signentry = new Regdata({

        Name: req.body.name,
        Email: req.body.email,
        Mobileno: req.body.mobileno,
        Address: req.body.address,
        Dob: req.body.dob,
        City: req.body.city,
        Hobbies: req.body.hobbies,
    })
    signentry.save();
});

route.get('/RegRouteUpdate/:id',async (req, res) => {

    const id = req.params.id;
    const UpdateData = req.body;
    const options = {new: true};

    const result = await Regdata.findByIdAndUpdate(id,UpdateData,options);
    res.send(result);
 
});

route.get('/DisplayStudRoute', async (req, res) => {

    const data = await Regdata.find();
    res.json(data)

});

route.get('/GetRoute/:id', async (req, res) => {
    try {
        const id = req.params.id;
       // console.log("getRoute"+id);
        const data = await Regdata.findById(id);
        res.json(data);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

route.delete('/Delete/:id', async (req, res) => {
    try {
        const id = req.params.id;
        const data = await Regdata.findByIdAndDelete(id);
        res.send(`Deleted ${data.name} has been deleted`);
    } catch (error) {
        console.error(error);
        res.status(400).json({ message: error.message });
    }
});

module.exports = route;